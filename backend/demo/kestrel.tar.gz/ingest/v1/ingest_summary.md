# Ingestion summary: Kestrel

- Source archive: `upload_1.zip` (SHA-256 `0102a956aa860fe3…`)
- Ingested: 2026-11-15T02:25:05Z · assumed time zone: America/Los_Angeles
- 57 files → 5630 records (5339 on the timeline), 15 media items, 246 distinct entities
- Time span: 2026-02-01T20:00:00Z → 2026-10-30T19:30:00Z
- Audit chain: valid (178 audit entries verified; head 358727485f1f72cb…)
- Manifest hash check: 56 files match

## Evidence by type

| Type | Files | Records |
|---|---|---|
| call_log | 2 | 2216 |
| records | 12 | 2145 |
| location | 1 | 509 |
| calendar | 1 | 224 |
| messages | 2 | 208 |
| statement | 9 | 175 |
| interview | 3 | 63 |
| dna | 2 | 54 |
| document | 4 | 16 |
| photo | 11 | 11 |
| email | 5 | 5 |
| video | 4 | 4 |
| case_manifest | 1 | 0 |

## Files

| File | Type (confidence) | Status | Records | Why this type |
|---|---|---|---|---|
| `kestrel_case/evidence/00_intake/custody_log.csv` | records (0.8) | parsed | 15 | generic timestamped records; file name hint |
| `kestrel_case/evidence/00_intake/incident_report.txt` | document (0.67) | parsed | 5 | free text with no stronger structure |
| `kestrel_case/evidence/00_intake/insurer_fnol.txt` | document (0.67) | parsed | 6 | free text with no stronger structure |
| `kestrel_case/evidence/01_bio/lab_report_dna.txt` | dna (0.79) | parsed | 47 | 22 DNA/lab terms (allele, locus, likelihood ratio, ...); file name hint |
| `kestrel_case/evidence/01_bio/str_profiles.csv` | dna (0.77) | parsed | 7 | 21 STR loci as columns; file name hint |
| `kestrel_case/evidence/02_video/f4cam01_2059.mp4` | video (0.99) | parsed | 1 | mp4 file signature |
| `kestrel_case/evidence/02_video/lobby01_1900.mp4` | video (0.99) | parsed | 1 | mp4 file signature |
| `kestrel_case/evidence/02_video/p2cam02_2135.mp4` | video (0.99) | parsed | 1 | mp4 file signature |
| `kestrel_case/evidence/02_video/p2cam02_2302.mp4` | video (0.99) | parsed | 1 | mp4 file signature |
| `kestrel_case/evidence/02_video/vms_analytics.csv` | records (0.67) | parsed | 98 | generic timestamped records |
| `kestrel_case/evidence/02_video/vms_export_index.csv` | records (0.8) | parsed | 9 | generic timestamped records; file name hint |
| `kestrel_case/evidence/03_photo/IMG_4402.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/IMG_4433.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/IMG_4458.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/IMG_4471.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_001.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_002.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_003.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_004.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_005.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/csu_006.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/03_photo/visitor_kiosk_1007.jpg` | photo (0.99) | parsed | 1 | jpeg file signature |
| `kestrel_case/evidence/04_msgs/extraction_notes.txt` | document (0.67) | parsed | 4 | free text with no stronger structure |
| `kestrel_case/evidence/04_msgs/halvorsen_iphone.csv` | messages (0.73) | parsed | 172 | message body (body) with other party (party_number) and direction columns; timestamp column |
| `kestrel_case/evidence/04_msgs/raman_android.csv` | messages (0.73) | parsed | 36 | message body (body) with other party (party_number) and direction columns; timestamp column |
| `kestrel_case/evidence/05_loc/cdr_4085550147.csv` | call_log (0.53) | parsed | 2093 | call duration (duration_s) with party columns; direction column (direction); file name hint |
| `kestrel_case/evidence/05_loc/cdr_4085550163.csv` | call_log (0.53) | parsed | 123 | call duration (duration_s) with party columns; direction column (direction); file name hint |
| `kestrel_case/evidence/05_loc/garage_lpr.csv` | records (0.67) | parsed | 256 | generic timestamped records |
| `kestrel_case/evidence/05_loc/halvorsen_timeline.json` | location (0.97) | parsed | 509 | Google semantic location history (timelineObjects) |
| `kestrel_case/evidence/05_loc/subscriber_0147.txt` | document (0.67) | parsed | 1 | free text with no stronger structure |
| `kestrel_case/evidence/06_logs/badge_bldg_e.csv` | records (0.8) | parsed | 947 | generic timestamped records; file name hint |
| `kestrel_case/evidence/06_logs/cabinet_acl.csv` | records (0.5) | parsed | 6 | generic table without recognized roles |
| `kestrel_case/evidence/06_logs/cabinet_audit.jsonl` | records (0.67) | parsed | 171 | generic timestamped records |
| `kestrel_case/evidence/06_logs/ceo_calendar.ics` | calendar (0.98) | parsed | 224 | iCalendar (VCALENDAR) export |
| `kestrel_case/evidence/06_logs/doors_readers.csv` | records (0.5) | parsed | 21 | generic table without recognized roles |
| `kestrel_case/evidence/06_logs/guard_tours.csv` | records (0.67) | parsed | 72 | generic timestamped records |
| `kestrel_case/evidence/06_logs/rfid_inventory.csv` | records (0.67) | parsed | 420 | generic timestamped records |
| `kestrel_case/evidence/06_logs/visitor_log.csv` | records (0.8) | parsed | 32 | generic timestamped records; file name hint |
| `kestrel_case/evidence/06_logs/ws_exec0001.csv` | records (0.43) | parsed | 98 | generic timestamped records |
| `kestrel_case/evidence/07_stmt/brandt.txt` | statement (0.69) | parsed | 24 | first-person narrative (15 first-person words) with 4 statement cues |
| `kestrel_case/evidence/07_stmt/e_halvorsen.txt` | statement (0.69) | parsed | 10 | first-person narrative (6 first-person words) with 4 statement cues |
| `kestrel_case/evidence/07_stmt/ellis.txt` | statement (0.71) | parsed | 17 | first-person narrative (13 first-person words) with 5 statement cues |
| `kestrel_case/evidence/07_stmt/ortega.txt` | statement (0.69) | parsed | 17 | first-person narrative (12 first-person words) with 6 statement cues |
| `kestrel_case/evidence/07_stmt/raman.txt` | statement (0.73) | parsed | 10 | first-person narrative (14 first-person words) with 6 statement cues |
| `kestrel_case/evidence/07_stmt/whitfield.txt` | statement (0.7) | parsed | 31 | first-person narrative (20 first-person words) with 9 statement cues |
| `kestrel_case/evidence/08_intv/bellini.txt` | statement (0.47) | parsed | 12 | first-person narrative (10 first-person words) with 0 statement cues |
| `kestrel_case/evidence/08_intv/chen.txt` | interview (0.54) | parsed | 8 | 8 speaker turns by 2 speakers |
| `kestrel_case/evidence/08_intv/halvorsen_1.txt` | interview (0.57) | parsed | 23 | 23 speaker turns by 3 speakers |
| `kestrel_case/evidence/08_intv/halvorsen_2.txt` | statement (0.47) | parsed | 36 | first-person narrative (20 first-person words) with 4 statement cues |
| `kestrel_case/evidence/08_intv/raman.txt` | statement (0.5) | parsed | 18 | first-person narrative (10 first-person words) with 3 statement cues |
| `kestrel_case/evidence/08_intv/shen.txt` | interview (0.58) | parsed | 32 | 32 speaker turns by 3 speakers |
| `kestrel_case/evidence/09_email/brandt_reply.eml` | email (0.97) | parsed | 1 | EML message headers |
| `kestrel_case/evidence/09_email/chen_travel.eml` | email (0.97) | parsed | 1 | EML message headers |
| `kestrel_case/evidence/09_email/ellis_brandt.eml` | email (0.97) | parsed | 1 | EML message headers |
| `kestrel_case/evidence/09_email/halvorsen_2255.eml` | email (0.97) | parsed | 1 | EML message headers |
| `kestrel_case/evidence/09_email/inv_alert.eml` | email (0.97) | parsed | 1 | EML message headers |
| `kestrel_case/evidence/MANIFEST.csv` | case_manifest (0.99) | parsed | 0 | evidence manifest (paths + SHA-256) |

## Key entities

- +14085550147 (phone): 2145 records
- Richard Halvorsen (person): 1000 records, 3 linked identifiers
- ELLIS, JORDAN (person): 227 records, 2 linked identifiers
- LPR-P2-IN (device): 169 records
- +14085550163 (phone): 124 records
- AURION\rhalvorsen (device): 98 records
- LPR-P2-OUT (device): 87 records
- DELGADO, RAY (AEGIS) (person): 84 records
- Priya Raman (person): 77 records
- AurionEDR (account): 76 records

## Gaps and caveats

- No machine-recorded activity for 3129.23 h (2026-02-01T20:00:00+00:00 → 2026-06-12T05:14:05+00:00)
- No machine-recorded activity for 298.59 h (2026-06-12T15:05:12+00:00 → 2026-06-25T01:40:33+00:00)
- No machine-recorded activity for 148.96 h (2026-06-25T02:02:10+00:00 → 2026-07-01T07:00:00+00:00)
- Timestamp assumptions: tz_assumed ×1473, window_is_visit_span ×509, window_is_event_span ×224, epoch_milliseconds ×171, human_reported ×36, am_pm_inferred_from_sequence ×8, am_pm_unspecified ×6, container_time_utc_by_spec ×4, window_is_recording_span ×4, midnight_ambiguous ×2, date_rolled_overnight ×1, am_pm_inferred_from_context ×1
